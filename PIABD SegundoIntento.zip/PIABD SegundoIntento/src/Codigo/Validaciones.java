
package Codigo;


public abstract class Validaciones {
    public static boolean correoValido(String correo) {
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+(com|org|net|edu|gob|mx)$";
        return correo.matches(regex);
    }
    
    public static boolean soloLetrasEspacios(String nombre){
        String regex = "^[a-zA-ZñÑÁÉÍÓÚáéíóú ]+$";
        return nombre.matches(regex);
    }
    
    public static boolean telefonoValido(String telefono){
        String regex = "^\\d{10}$";
        return telefono.matches(regex);
    }
    
    public static boolean soloNumeros(String num){
        String regex = "^\\d+$";
        return num.matches(regex);
    }
    
}
