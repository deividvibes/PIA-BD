
package Codigo;

/**
 *
 * @author edere
 */
public class Huesped {

    public int getIdHuesped() {
        return idHuesped;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getINE() {
        return INE;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public String getEstado() {
        return estado;
    }

    public String getMunicipio() {
        return municipio;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setIdHuesped(int idHuesped) {
        this.idHuesped = idHuesped;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public void setINE(String INE) {
        this.INE = INE;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public static int idHuespedActual = 1000;
    private int idHuesped;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String INE;
    private String telefono;
    private String correo;  
    private String estado;
    private String municipio;
    private String direccion;

    public Huesped(String nombre, String apellidoPaterno, String apellidoMaterno, String INE, String telefono, String correo, String estado, String municipio, String direccion){
        this.idHuesped = idHuespedActual++;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.INE = INE;
        this.telefono = telefono;
        this.correo = correo;
        this.estado = estado;
        this.municipio = municipio;
        this.direccion = direccion;
    }

}
