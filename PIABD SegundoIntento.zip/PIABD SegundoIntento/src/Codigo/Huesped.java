
package Codigo;

/**
 *
 * @author edere
 */
public class Huesped {

    public int getEstado() {
        return Estado;
    }

    public int getMunicipio() {
        return Municipio;
    }

    public void setEstado(int Estado) {
        this.Estado = Estado;
    }

    public void setMunicipio(int Municipio) {
        this.Municipio = Municipio;
    }

    public int getIdHuesped() {
        return idHuesped;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getINE() {
        return INE;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }


    public String getDireccion() {
        return direccion;
    }

    public void setIdHuesped(int idHuesped) {
        this.idHuesped = idHuesped;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public void setINE(String INE) {
        this.INE = INE;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }


    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public static int idHuespedActual = 1000;
    private int idHuesped;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String INE;
    private String telefono;
    private String correo;  
    private int Estado;
    private int Municipio;
    private String direccion;

    public Huesped(String nombre, String apellidoPaterno, String apellidoMaterno, String INE, String telefono, String correo, String estado, String municipio, String direccion){
        this.idHuesped = idHuespedActual++;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.INE = INE;
        this.telefono = telefono;
        this.correo = correo;
        //this.idEstado = CONSULTAESTADO(estado);
        //this.idMunicipio = CONSULTAMUNICIPIO(municipio);
        this.direccion = direccion;
    }

}
