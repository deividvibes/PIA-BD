
package Codigo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;



/**
 *
 * @author USER
 */
public class main extends Application{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        //Cargamos nuestro archivo fxml a la clase Parent
        Parent root = FXMLLoader.load(getClass().getResource("/Menu/Menu.fxml"));
        
        //Creamos una nueva escena en root
        Scene scene = new Scene(root);

        //Creamos un objeto Imagen con el icono
        Image icon = new Image("/Recursos/icon.png");
        
        //Establecemos el icono deseado
        stage.getIcons().add(icon);
        //Establecemos el titulo de la ventana
        stage.setTitle("BISON INN");
        
        //Establecemos la escena inicial, en este caso, la escena de Menu Principal
        stage.setScene(scene);
        //mostramos el escenario, con la escena ya montada
        stage.show();
    }
    
}
