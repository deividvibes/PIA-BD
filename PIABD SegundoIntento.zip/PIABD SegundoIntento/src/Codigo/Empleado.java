
package Codigo;

import static Codigo.Huesped.idHuespedActual;


public class Empleado {

    public String getNombre() {
        return nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public String getINE() {
        return INE;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public int getIdMunicipio() {
        return idMunicipio;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getCargo() {
        return cargo;
    }

    public double getSalario() {
        return salario;
    }

    public int getIdTipo() {
        return idTipo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public void setINE(String INE) {
        this.INE = INE;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void setIdTipo(int idTipo) {
        this.idTipo = idTipo;
    }
    public static int IdActualEmpleado = 2000;
    private int idEmpleado;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String INE;
    private String telefono;
    private String correo;  
    private int idEstado;
    private int idMunicipio;
    private String direccion;
    private String cargo;
    private double salario;
    private int idTipo;
    
    public Empleado(String nombre, 
            String apellidoPaterno, 
            String apellidoMaterno, 
            String INE,
            String telefono,
            String correo,
            String Estado,
            String Municipio,
            String direccion,
            String cargo,
            String salario,
            String tipo){
        
        this.idEmpleado = IdActualEmpleado++;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.INE = INE;
        this.telefono = telefono;
        this.correo = correo;
        //this.idEstado = CONSULTAESTADO(estado);
        //this.idMunicipio = CONSULTAMUNICIPIO(municipio);
        this.direccion = direccion;
        this.cargo = cargo;
        this.salario = Double.parseDouble(salario);
        //this.idTipo = CONSULTATIPO(tipo);
        
    }
    
}
