/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Codigo;

import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author USER
 */
public class Tarjeta {

    public int getIdTarjeta() {
        return idTarjeta;
    }

    public int getIdHuesped() {
        return idHuesped;
    }

    public String getTipoTarjeta() {
        return tipoTarjeta;
    }

    public String getBanco() {
        return banco;
    }

    public String getNombreTitular() {
        return nombreTitular;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public Date getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setIdTarjeta(int idTarjeta) {
        this.idTarjeta = idTarjeta;
    }

    public void setIdHuesped(int idHuesped) {
        this.idHuesped = idHuesped;
    }

    public void setTipoTarjeta(String tipoTarjeta) {
        this.tipoTarjeta = tipoTarjeta;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    public void setFechaCaducidad(Date fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }
    public static int idActualTarjeta = 3000;
    private int idTarjeta;
    private int idHuesped;
    private String tipoTarjeta;
    private String banco;
    private String nombreTitular;
    private String numeroTarjeta;
    private Date fechaCaducidad;
    
    public Tarjeta(String nombreHuesped, String tipoTarjeta, String banco, String nombreTitular, String numeroTarjeta, LocalDate fechaCaducidad){
        this.idTarjeta = idActualTarjeta++;
        //this.idHuesped = IDHUESPEDCONSULTAPORNOMBRE(nombreHuesped);
        this.tipoTarjeta = tipoTarjeta;
        this.banco = banco;
        this.nombreTitular = nombreTitular;
        this.numeroTarjeta = numeroTarjeta;
        this.fechaCaducidad = Date.valueOf(fechaCaducidad);
    }
    
}
