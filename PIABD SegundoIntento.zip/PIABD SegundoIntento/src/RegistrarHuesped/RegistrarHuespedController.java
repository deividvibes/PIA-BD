
package RegistrarHuesped;

import Codigo.Huesped;
import Codigo.Validaciones;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegistrarHuespedController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;
    
    public void pulsarBotonListo(ActionEvent click) throws IOException{
        
        Huesped h = new Huesped(TextNombre.getText(),
                TextApellidoPaterno.getText(),
                TextApellidoMaterno.getText(),
                TextIne.getText(),
                TextTelefono.getText(),
                TextMail.getText(),
                ComboEstado.getValue(),
                ComboMunicipio.getValue(),
                TextDireccion.getText());
        
        //AÑADIR EL HUESPED H A LA BD

        root = FXMLLoader.load(getClass().getResource("/Menu/Menu.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonVolver(ActionEvent click) throws IOException{
        //Creamos una alerta que se activara al hacer click en el boton Salir
        Alert alertaClose = new Alert(Alert.AlertType.CONFIRMATION);
        //Le damos un titulo a la ventana de alerta
        alertaClose.setTitle("ADVERTENCIA");
        //Establecemos el texto de la alerta
        alertaClose.setHeaderText("¿Estas seguro que deseas salir de la ventana? El registro no se guardará");
        
        //Si hacemos click en aceptar la alerta, la ventana será cerrada
        if(alertaClose.showAndWait().get() == ButtonType.OK){
            root = FXMLLoader.load(getClass().getResource("/Menu/Menu.fxml"));

            stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

            scene = new Scene(root);

            stage.setScene(scene);
            stage.show();
        }   
    }
   
    @FXML
    private TextField TextNombre,TextApellidoPaterno,TextApellidoMaterno,TextTelefono,TextDireccion,TextIne, TextMail;
    List<TextField> camposTexto;
    @FXML
    private ComboBox<String> ComboEstado,ComboMunicipio;
    List<ComboBox<String>> combos;
    @FXML
    private Button botonListo;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
         
        camposTexto = List.of(TextNombre,TextApellidoPaterno,TextApellidoMaterno,TextTelefono,TextDireccion,TextIne,TextMail);
        
        combos = List.of(ComboEstado,ComboMunicipio);
        
        List<String> estados;
        estados = List.of("Nuevo Leon","Coahuila","Tamaulipas");
        //estados = obtenerEstadosDesdeMySQL(); AQUI PONER UNA CONSULTA DE TODOS LOS ESTADOS
        ComboEstado.getItems().addAll(estados);
        ComboEstado.setEditable(true);

        ComboMunicipio.setDisable(true);
        ComboMunicipio.setEditable(true);

        // Listener para cuando el usuario seleccione un estado
        ComboEstado.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                
                List<String> municipios;
                municipios = List.of("Monterrey","Laredo","Allende");
                //municipios = obtenerMunicipiosDesdeMySQL(newVal); AQUI HAY QUE PONER LOS MUNICIPIOS DE X ESTADO
                ComboMunicipio.getItems().setAll(municipios);
                ComboMunicipio.setDisable(false);
            }
        });
        
        
        //Validar si algun campo está vacio
        Runnable validarTodo = () -> {
        boolean algunCampoInvalido = camposTexto.stream()
            .peek(tf -> {
                boolean invalido = tf.getText().trim().isEmpty();
                if (tf == TextMail && !invalido) {
                    invalido = !Validaciones.correoValido(tf.getText().trim());
                }
                if (tf == TextTelefono && !invalido) {
                    invalido = !Validaciones.telefonoValido(tf.getText().trim());
                }
                if ((tf == TextNombre || tf == TextApellidoPaterno || tf == TextApellidoMaterno) && !invalido) {
                    invalido = !Validaciones.soloLetrasEspacios(tf.getText().trim());
                }
                tf.setStyle(invalido ? "-fx-border-color: red;" : null);
            })
            .anyMatch(tf -> {
                if (tf == TextMail) {
                    return tf.getText().trim().isEmpty() || !Validaciones.correoValido(tf.getText().trim());
                }
                if (tf == TextTelefono) {
                    return tf.getText().trim().isEmpty() || !Validaciones.telefonoValido(tf.getText().trim());
                }
                if(tf == TextNombre || tf == TextApellidoPaterno || tf == TextApellidoMaterno){
                    return tf.getText().trim().isEmpty() || !Validaciones.soloLetrasEspacios(tf.getText().trim()); 
                }
                return tf.getText().trim().isEmpty();
            });

        boolean algunComboVacio = combos.stream()
            .peek(cb -> cb.setStyle(cb.getValue() == null ? "-fx-border-color: red;" : null))
            .anyMatch(cb -> cb.getValue() == null);

        botonListo.setDisable(algunCampoInvalido || algunComboVacio);
};



    camposTexto.forEach(tf -> tf.textProperty().addListener((obs, o, n) -> validarTodo.run()));
    combos.forEach(cb -> cb.valueProperty().addListener((obs, o, n) -> validarTodo.run()));
    



    

    }
    

    
}
