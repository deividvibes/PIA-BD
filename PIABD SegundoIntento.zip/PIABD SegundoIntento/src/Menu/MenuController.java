
package Menu;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MenuController{

    private Stage stage;
    private Scene scene;
    private Parent root;
    
    public void pulsarBotonRegistrarHuesped(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/RegistrarHuesped/RegistrarHuesped.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonRegistrarTarjeta(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/RegistrarTarjeta/RegistrarTarjeta.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonRegistrarEmpleado(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/RegistrarEmpleado/RegistrarEmpleado.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonRegistrarReserva(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/RegistrarReserva/RegistrarReserva.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonCheckInOut(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/CheckInOut/CheckInOut.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonTotalAPagar(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/TotalAPagar/TotalAPagar.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
    public void pulsarBotonInfoHuesped(ActionEvent click) throws IOException{

        root = FXMLLoader.load(getClass().getResource("/InfoHuesped/InfoHuesped.fxml"));

        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();

        scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }
    
}
